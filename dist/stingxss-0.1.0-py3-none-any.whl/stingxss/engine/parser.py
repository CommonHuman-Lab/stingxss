"""
StingXSS — engine/parser.py
HTML / JavaScript context analyser.

Given an HTTP response body and the unique marker we injected,
determine the reflection context so payload_gen can pick the
right payload class.
"""

from __future__ import annotations

import html
import re
from typing import Optional

from .reporter import ReflectionContext

# ---------------------------------------------------------------------------
# Unique probe marker injected during reflection testing
# ---------------------------------------------------------------------------
PROBE_MARKER = "vXSS7b3e"


# ---------------------------------------------------------------------------
# Context detection
# ---------------------------------------------------------------------------

def find_context(body: str, marker: str = PROBE_MARKER) -> ReflectionContext:
  """
  Locate `marker` inside `body` and return the HTML/JS context it appears in.

  Strategy:
  1. Find all occurrences of the marker (case-insensitive, handles HTML-encoding).
  2. For the first occurrence, walk backwards through the raw body to determine
     the enclosing syntactic context.
  """
  # Normalise: sometimes servers HTML-encode the reflection
  normalised = html.unescape(body)

  pos = normalised.lower().find(marker.lower())
  if pos == -1:
    return ReflectionContext.UNKNOWN

  before = normalised[:pos]
  return _classify(before, normalised, pos)


def is_reflected(body: str, marker: str = PROBE_MARKER) -> bool:
  """Quick check — is the marker anywhere in the response?"""
  return marker.lower() in html.unescape(body).lower()


# ---------------------------------------------------------------------------
# Internal classifier
# ---------------------------------------------------------------------------

def _classify(before: str, full: str, pos: int) -> ReflectionContext:
  # ---- 1. Are we inside a <script> block? ---------------------------------
  last_script_open  = _rfind_tag(before, "script", opening=True)
  last_script_close = _rfind_tag(before, "script", opening=False)

  in_script = (
    last_script_open is not None
    and (last_script_close is None or last_script_close < last_script_open)
  )

  if in_script:
    script_content = before[last_script_open:]
    return _classify_script(script_content, full[pos:pos + 30])

  # ---- 2. Are we inside an HTML comment? -----------------------------------
  if _in_comment(before):
    return ReflectionContext.COMMENT

  # ---- 3. Are we inside a <style> block? -----------------------------------
  last_style_open  = _rfind_tag(before, "style", opening=True)
  last_style_close = _rfind_tag(before, "style", opening=False)
  in_style = (
    last_style_open is not None
    and (last_style_close is None or last_style_close < last_style_open)
  )
  if in_style:
    return ReflectionContext.CSS

  # ---- 4. Are we inside an HTML tag attribute? ----------------------------
  attr_ctx = _classify_attribute(before)
  if attr_ctx is not None:
    return attr_ctx

  # ---- 5. Default: HTML body text -----------------------------------------
  return ReflectionContext.HTML_BODY


# ---------------------------------------------------------------------------
# Script-context classifier
# ---------------------------------------------------------------------------

def _classify_script(script_before: str, after_snippet: str) -> ReflectionContext:
  """
  Within a script block, determine whether the marker is:
  - inside a double-quoted string
  - inside a single-quoted string
  - inside a template literal
  - bare (not in any string)
  """
  # Walk the script content counting unescaped string delimiters
  in_double = False
  in_single = False
  in_template = False
  i = 0
  s = script_before
  while i < len(s):
    c = s[i]
    if c == "\\" and i + 1 < len(s):
      i += 2  # skip escaped char
      continue
    if c == '"'  and not in_single and not in_template:
      in_double = not in_double
    elif c == "'" and not in_double and not in_template:
      in_single = not in_single
    elif c == "`" and not in_double and not in_single:
      in_template = not in_template
    i += 1

  if in_double:
    return ReflectionContext.SCRIPT_STRING_D
  if in_single:
    return ReflectionContext.SCRIPT_STRING_S
  return ReflectionContext.SCRIPT_BARE


# ---------------------------------------------------------------------------
# Attribute-context classifier
# ---------------------------------------------------------------------------

# Matches the last opening tag before the marker (greedy backwards search)
_LAST_TAG_RE = re.compile(r"<(\w[\w:-]*)([^>]*)$", re.DOTALL)

# Event handler attribute names
_EVENT_ATTRS = re.compile(
  r"\bon\w+\s*=\s*(['\"]?)$",
  re.IGNORECASE,
)

# URL-bearing attributes
_URL_ATTRS = re.compile(
  r"\b(?:href|src|action|formaction|data|ping|poster|background)\s*=\s*(['\"]?)$",
  re.IGNORECASE,
)


def _classify_attribute(before: str) -> Optional[ReflectionContext]:
  """
  Determine if we're inside an HTML tag attribute and which kind.
  Returns None if we're NOT inside a tag.
  """
  # Find the last unclosed < — if there's a > after the last <, we're not in a tag
  last_open  = before.rfind("<")
  last_close = before.rfind(">")

  if last_open == -1 or last_close > last_open:
    return None  # Not inside a tag

  inside_tag = before[last_open:]

  # Event handler attribute?
  if _EVENT_ATTRS.search(inside_tag):
    return ReflectionContext.EVENT_HANDLER

  # URL attribute?
  if _URL_ATTRS.search(inside_tag):
    return ReflectionContext.URL_ATTR

  # Generic attribute — determine quoting
  # Find the last = sign to understand the attribute value context
  eq_pos = inside_tag.rfind("=")
  if eq_pos == -1:
    # We're in the tag but not yet in an attribute value (e.g. a tag name itself)
    return ReflectionContext.HTML_BODY  # treat as body injection via tag break

  after_eq = inside_tag[eq_pos + 1:].lstrip()
  if after_eq.startswith('"'):
    return ReflectionContext.ATTR_DOUBLE
  if after_eq.startswith("'"):
    return ReflectionContext.ATTR_SINGLE
  return ReflectionContext.ATTR_UNQUOTED


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _rfind_tag(text: str, tag: str, opening: bool) -> Optional[int]:
  """Return the position of the last opening or closing tag, or None."""
  if opening:
    pattern = re.compile(rf"<{tag}[\s>/]", re.IGNORECASE)
  else:
    pattern = re.compile(rf"</{tag}\s*>", re.IGNORECASE)

  last = None
  for m in pattern.finditer(text):
    last = m.start()
  return last


def _in_comment(before: str) -> bool:
  """True if the position is inside an HTML comment."""
  opens  = len(re.findall(r"<!--", before))
  closes = len(re.findall(r"-->", before))
  return opens > closes
