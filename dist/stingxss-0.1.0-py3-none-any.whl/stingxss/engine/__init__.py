"""
StingXSS — engine/__init__.py
Public API surface for the StingXSS engine.

Usage (standalone):
    from stingxss.engine import scan, ScanOptions, ScanResult

Usage (NyxStrike plugin):
    from plugins.tools.stingxss.engine import scan, ScanOptions, ScanResult
"""

from .reporter import (
  BlindFinding,
  DomFinding,
  FindingType,
  ReflectedFinding,
  ReflectionContext,
  ScanResult,
)
from .scanner import ScanOptions, scan

__all__ = [
  "scan",
  "ScanOptions",
  "ScanResult",
  "ReflectionContext",
  "FindingType",
  "ReflectedFinding",
  "DomFinding",
  "BlindFinding",
]
